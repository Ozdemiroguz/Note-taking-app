﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace W3_WebControls
{
    public partial class Default : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
                TextBox1.TextMode = TextBoxMode.Password;
                TextBox1.BackColor = Color.AliceBlue;
                Label1.Text += "Page Load event has occured.";
            }
        }
        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblName.Text = ListBox1.SelectedItem.Value.ToString();
            //body.Attributes.Add("onload", "alert('" + ListBox1.SelectedValue + "');");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            int n = 5;
            while (n > 0) {
                Label1.Text += n.ToString() + "\r\n"; n--;
            }


            Label1.Text += "Button1 Click event has occured.";
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblName.Text = DropDownList1.SelectedItem.Value.ToString();
            DropDownList1.Items.Add("Gülce Demirbaş");
        }
    }
}