﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _02_CurrencyConverterApp
{
    public partial class WebForm1 : System.Web.UI.Page
    {
      
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnConvertDollars_Click(object sender, EventArgs e)
        {
            double dollars = double.Parse(tbDollars.Text);
            double turkish = dollars * 5.34;
            lblResult.Text = dollars.ToString() + " dollars equal to " + turkish.ToString() + " TL.";
        }
        protected void btnConvertEuros_Click(object sender, EventArgs e)
        {
            try
            {
                double euros = double.Parse(tbEuros.Text);
                double turkish = euros * 6.09;
                lblResult.Text = euros.ToString("F2") + " euros equal to " + turkish.ToString("F2") + " TL.";
            }
            catch (FormatException)
            {
                lblResult.Text = "A format error has occured!";
            }
        }
    }
}